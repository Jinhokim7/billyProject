package com.billy.DAO;

import org.springframework.stereotype.Repository;

@Repository
public class BillyMemberDAOImpl implements IF_billyMemberDAO {
	
	private static String mapperQuery = "com.billy.DAO.IF_billyMemberDAO";
	
}
