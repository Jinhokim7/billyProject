package com.billy.Service;

import org.springframework.stereotype.Service;

@Service
public class BillyMemberServiceImpl implements IF_billyMemberService{

}
